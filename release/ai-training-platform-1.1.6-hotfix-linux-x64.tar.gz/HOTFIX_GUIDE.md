# AI 训战平台 v1.1.6 Linux 热补丁指导书

适用范围：通过单服务器离线包部署在 Linux `/opt/ai-training` 的 `v1.1.0`–`v1.1.3`。本补丁只替换平台 API 和网页构建产物，不修改 PostgreSQL、交付件、评测引擎、配置文件或历史记录。**没有数据库迁移。**

## 本次内容

**新增：管理端可以看到评测分数**

- 评测中心的提交列表在状态右侧显示评测总分；成绩尚未公布的训战显示“未公布”而不是留空。
- 展开某份提交时显示总分、四个能力维度得分和完成时间；报告按需拉取，未完成评测不会触发请求。
- 此前管理端完全没有查看分数的入口，只能向学员索要或直接查数据库。

**同时包含此前版本的修复**

- 评测失败后再次发起评测产生相同幂等键、PostgreSQL 返回 500（v1.1.3）。
- 一人评测中导致同场其他人无法提交（v1.1.4）。
- 热补丁安装器读取发布包中不存在的根 `package.json`，导致版本闸恒失败。

打完补丁后网页页脚显示 **v1.1.6**，可据此确认生效。注意安装器不会改写 `VERSION` 文件，该文件仍显示基线安装版本。

## 操作步骤

将 `ai-training-platform-1.1.6-hotfix-linux-x64.tar.gz` 上传到服务器，例如 `/opt`：

```bash
cd /opt
sha256sum -c ai-training-platform-1.1.6-hotfix-linux-x64.tar.gz.sha256
mkdir -p ai-training-hotfix-1.1.6
tar -xzf ai-training-platform-1.1.6-hotfix-linux-x64.tar.gz -C ai-training-hotfix-1.1.6
cd ai-training-hotfix-1.1.6
sudo ./apply-hotfix.sh /opt/ai-training /opt/ai-training/deploy/single-node/.env
```

脚本会依次执行文件校验、原构建产物备份、停止服务、替换、启动和健康检查。失败会自动恢复原构建产物。

## 验证

```bash
cat /opt/ai-training/runtime-state/hotfix-version.json
/opt/ai-training/deploy/single-node/manage.sh Status --environment /opt/ai-training/deploy/single-node/.env
curl -I http://127.0.0.1:8080/
```

逐项确认：

1. 网页页脚显示 `v1.1.6`。
2. 评测中心的已完成提交，状态右侧出现分数；点击“查看提交”展开后显示总分和四个维度得分。
3. 失败记录显示“重新评测”，点击后直接创建新批次，不需要删除提交。
4. 一名学员评测进行中时，另一账号进入同场训战仍可正常提交。

## 手动回滚

脚本最后会打印备份目录。需要回滚时，将下面的 `<备份目录>` 替换为实际路径：

```bash
cd /opt/ai-training
sudo ./deploy/single-node/manage.sh Stop --environment ./deploy/single-node/.env
sudo rm -rf ./services/platform-api/dist ./apps/web/dist
sudo tar -xzf <备份目录>/application-dist-before.tar.gz -C /opt/ai-training
sudo ./deploy/single-node/manage.sh Start --environment ./deploy/single-node/.env
```

不要删除或重建数据库，不要删除 `data/`、`runtime-state/evaluation-*` 或员工交付件。

